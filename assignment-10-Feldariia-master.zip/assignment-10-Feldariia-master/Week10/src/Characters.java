
public class Characters {
	//Declare variables
	public String name; 
	public double stats; 
	public double health;

	//Declare constructor
	public Characters(String name, double stats) {
		this.name = name; 
		this.stats = stats; 
	}
	//Return the names
	public String getName() { 
		return name; 
	} 
}
